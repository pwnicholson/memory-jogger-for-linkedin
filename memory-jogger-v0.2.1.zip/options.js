(() => {
  console.log('[Memory Jogger] Options page loaded');

  const notesList = document.getElementById('mjli-notes-list');
  const storageInfo = document.getElementById('mjli-storage-usage');
  const exportBtn = document.getElementById('mjli-export-btn');
  const importBtn = document.getElementById('mjli-import-btn');
  const importFile = document.getElementById('mjli-import-file');
  const editModal = document.getElementById('mjli-edit-modal');
  const modalClose = document.getElementById('mjli-modal-close');
  const modalCancel = document.getElementById('mjli-modal-cancel');
  const modalSave = document.getElementById('mjli-modal-save');
  const editTextarea = document.getElementById('mjli-edit-textarea');
  const editCounter = document.getElementById('mjli-edit-counter');
  const editProfileName = document.getElementById('mjli-edit-profile-name');
  const searchInput = document.getElementById('mjli-search-input');

  let currentEditingKey = null;
  let allNotesData = {}; // Cache for filtering

  // --- Storage Helpers ---
  function storageGet(key) {
    return new Promise((resolve) => {
      try {
        if (!chrome || !chrome.storage || !chrome.storage.sync || !chrome.runtime) {
          resolve("");
          return;
        }
        
        chrome.storage.sync.get([key], (result) => {
          try {
            if (chrome.runtime.lastError) {
              resolve("");
            } else {
              resolve(result[key] || "");
            }
          } catch (e) {
            resolve("");
          }
        });
      } catch (e) {
        resolve("");
      }
    });
  }

  function storageSet(key, value) {
    return new Promise((resolve) => {
      try {
        if (!chrome || !chrome.storage || !chrome.storage.sync || !chrome.runtime) {
          resolve();
          return;
        }
        
        chrome.storage.sync.set({ [key]: value }, () => {
          try {
            if (chrome.runtime.lastError) {
              console.log('[Memory Jogger] Note saved (sync may be pending)');
            } else {
              console.log('[Memory Jogger] Saved:', key);
            }
          } catch (e) {
            // Silent
          }
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  function storageGetAll() {
    return new Promise((resolve) => {
      try {
        if (!chrome || !chrome.storage || !chrome.storage.sync || !chrome.runtime) {
          resolve({});
          return;
        }
        
        chrome.storage.sync.get(null, (result) => {
          try {
            if (chrome.runtime.lastError) {
              resolve({});
            } else {
              resolve(result || {});
            }
          } catch (e) {
            resolve({});
          }
        });
      } catch (e) {
        resolve({});
      }
    });
  }

  function storageRemove(key) {
    return new Promise((resolve) => {
      try {
        if (!chrome || !chrome.storage || !chrome.storage.sync || !chrome.runtime) {
          resolve();
          return;
        }
        
        chrome.storage.sync.remove([key], () => {
          try {
            if (chrome.runtime.lastError) {
              console.log('[Memory Jogger] Note deleted (sync may be pending)');
            } else {
              console.log('[Memory Jogger] Deleted:', key);
            }
          } catch (e) {
            // Silent
          }
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  // --- Utility Functions ---
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  function getInitials(name) {
    return name.split(' ').map(part => part[0]).join('').toUpperCase().substring(0, 2);
  }

  function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  }

  // --- Update Storage Info ---
  async function updateStorageInfo() {
    const allData = await storageGetAll();
    const noteKeys = Object.keys(allData).filter(k => k.startsWith('note:'));
    const totalBytes = JSON.stringify(allData).length;
    const quotaBytes = 102400; // chrome.storage.sync quota
    const percentUsed = Math.round((totalBytes / quotaBytes) * 100);
    
    storageInfo.textContent = `${formatBytes(totalBytes)} / ${formatBytes(quotaBytes)} (${percentUsed}%) · ${noteKeys.length} note${noteKeys.length !== 1 ? 's' : ''}`;
  }

  // --- Load and Display Notes ---
  async function loadAndDisplayNotes(filterText = '') {
    notesList.innerHTML = '<div class="mjli-loading">Loading notes...</div>';
    
    const allData = await storageGetAll();
    const noteEntries = Object.entries(allData).filter(([key]) => key.startsWith('note:'));
    
    allNotesData = {}; // Store for filtering
    
    await updateStorageInfo();

    if (noteEntries.length === 0) {
      notesList.innerHTML = `
        <div class="mjli-empty-state">
          <div class="mjli-empty-state-icon">📭</div>
          <h3>No notes yet</h3>
          <p>Your saved notes will appear here. Add notes when viewing profiles on LinkedIn!</p>
        </div>
      `;
      return;
    }

    notesList.innerHTML = '';
    
    // Build notes data with metadata
    const filter = filterText.toLowerCase();
    let matchedCount = 0;

    for (const [key, noteText] of noteEntries) {
      const profileKey = key.replace('note:', '');
      const metaKey = key.replace('note:', 'meta:');
      const profileName = profileKey.replace('/in/', '');
      
      // Build displayName with multiple fallback strategies
      let displayName = '';
      let initials = '';
      
      // Strategy 1: Try to load from metadata first
      if (allData[metaKey]) {
        try {
          const metadata = JSON.parse(allData[metaKey]);
          // Only use metadata name if it's a valid, non-empty string
          if (metadata.name && metadata.name.trim() && metadata.name.length > 1) {
            // Extra validation: reject names that look like UI artifacts
            const name = metadata.name.trim();
            // Skip if it starts with special characters like "(1)", "[", etc
            if (!/^[\(\[\{]/.test(name) && !/^[\d\-]+$/.test(name)) {
              displayName = name;
            }
          }
        } catch (e) {
          // Metadata parse error, continue to fallback
        }
      }
      
      // Strategy 2: If no valid metadata name, create from profile URL
      if (!displayName) {
        // Try to extract just the name parts (remove numeric user IDs if present)
        // LinkedIn URLs like /in/matt-jalove-07057551 should become "Matt Jalove" not "Matt Jalove 07057551"
        let nameFromUrl = profileName;
        
        // Remove trailing numeric ID (common pattern: name-number)
        // Match last segment if it's all numbers, and remove it
        nameFromUrl = nameFromUrl.replace(/-\d+$/, '');
        
        // Now convert remaining URL to a name
        // /in/charles-settles -> "Charles Settles"
        displayName = nameFromUrl
          .split('-')
          .map(part => {
            // Capitalize first letter, lowercase rest
            if (part.length === 0 || /^\d+$/.test(part)) return '';
            return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
          })
          .filter(part => part.length > 0)
          .join(' ');
        
        // Fallback if everything filtered out
        if (!displayName || displayName.length === 0) {
          displayName = profileName.replace(/-/g, ' ').replace(/\d+/g, '').trim() || profileName;
        }
      }
      
      // Generate initials from displayName
      initials = getInitials(displayName || profileName);

      // Store for reference
      allNotesData[key] = {
        profileKey,
        displayName,
        profileImage: '',
        profileName,
        noteText,
        initials
      };

      // Filter logic
      if (filter) {
        const matchesDisplay = displayName.toLowerCase().includes(filter);
        const matchesProfileKey = profileKey.toLowerCase().includes(filter);
        const matchesNoteText = noteText.toLowerCase().includes(filter);
        
        if (!matchesDisplay && !matchesProfileKey && !matchesNoteText) {
          continue;
        }
      }

      matchedCount++;

      // Create note item
      const noteItem = document.createElement('div');
      noteItem.className = 'mjli-note-item';
      
      noteItem.innerHTML = `
        <div class="mjli-note-item-header">
          <div class="mjli-note-item-profile">
            <div class="mjli-profile-avatar">${escapeHtml(initials)}</div>
            <div class="mjli-profile-details">
              <a href="https://www.linkedin.com${profileKey}" target="_blank" class="mjli-profile-name">
                ${escapeHtml(displayName)}
              </a>
              <a href="https://www.linkedin.com${profileKey}" target="_blank" class="mjli-profile-key">
                ${escapeHtml(profileKey)}
              </a>
            </div>
          </div>
          <div class="mjli-note-item-actions">
            <button class="mjli-btn-secondary mjli-edit-note-btn" data-key="${escapeHtml(key)}">Edit</button>
            <button class="mjli-btn-danger mjli-delete-note-btn" data-key="${escapeHtml(key)}">Delete</button>
          </div>
        </div>
        <div class="mjli-note-item-content">${escapeHtml(noteText)}</div>
        <div class="mjli-note-metadata">
          ${noteText.length} characters
        </div>
      `;


      // Edit button listener
      noteItem.querySelector('.mjli-edit-note-btn').addEventListener('click', (e) => {
        const key = e.target.getAttribute('data-key');
        const data = allNotesData[key];
        if (data) {
          openEditModal(key, data.displayName, data.noteText);
        }
      });

      // Delete button listener
      noteItem.querySelector('.mjli-delete-note-btn').addEventListener('click', async (e) => {
        const key = e.target.getAttribute('data-key');
        const data = allNotesData[key];
        const name = data ? data.displayName : 'this person';
        if (confirm(`Delete note for ${name}?`)) {
          await storageRemove(key);
          // Also try to remove metadata
          const metaKey = key.replace('note:', 'meta:');
          await storageRemove(metaKey);
          loadAndDisplayNotes(filterText);
        }
      });

      notesList.appendChild(noteItem);
    }

    // Show filter results message if filtering
    if (filter && matchedCount === 0) {
      notesList.innerHTML = `
        <div class="mjli-empty-state">
          <div class="mjli-empty-state-icon">🔍</div>
          <h3>No matches found</h3>
          <p>No notes match "<strong>${escapeHtml(filter)}</strong>"</p>
        </div>
      `;
    } else if (filter && matchedCount < noteEntries.length) {
      const summary = document.createElement('div');
      summary.className = 'mjli-filter-summary';
      summary.textContent = `Showing ${matchedCount} of ${noteEntries.length} notes`;
      notesList.insertBefore(summary, notesList.firstChild);
    }
  }

  // --- Edit Modal ---
  function openEditModal(key, profileName, noteText) {
    currentEditingKey = key;
    editProfileName.textContent = profileName.replace(/-/g, ' ');
    editTextarea.value = noteText;
    updateEditCounter();
    editModal.style.display = 'flex';
    editTextarea.focus();
  }

  function closeEditModal() {
    editModal.style.display = 'none';
    currentEditingKey = null;
  }

  function updateEditCounter() {
    editCounter.textContent = `${editTextarea.value.length} / 200`;
  }

  // Modal event listeners
  modalClose.addEventListener('click', closeEditModal);
  modalCancel.addEventListener('click', closeEditModal);
  editTextarea.addEventListener('input', updateEditCounter);

  modalSave.addEventListener('click', async () => {
    if (!currentEditingKey) return;
    
    const newText = editTextarea.value.trim();
    await storageSet(currentEditingKey, newText);
    closeEditModal();
    loadAndDisplayNotes();
  });

  // Close modal on escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && editModal.style.display === 'flex') {
      closeEditModal();
    }
  });

  // --- Search/Filter ---
  if (searchInput) {
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        loadAndDisplayNotes(e.target.value);
      }, 300); // Debounce for 300ms
    });
  }

  // --- Export Notes ---
  exportBtn.addEventListener('click', async () => {
    const allData = await storageGetAll();
    const noteEntries = Object.entries(allData).filter(([key]) => key.startsWith('note:'));
    
    const exportData = {};
    for (const [key, value] of noteEntries) {
      const profileKey = key.replace('note:', '');
      exportData[profileKey] = value;
    }

    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `memory-jogger-notes-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    console.log('[Memory Jogger] Exported', noteEntries.length, 'notes');
  });

  // --- Import Notes ---
  importBtn.addEventListener('click', () => {
    importFile.click();
  });

  importFile.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const importedData = JSON.parse(event.target.result);
        
        if (!importedData || typeof importedData !== 'object') {
          alert('Invalid file format. Please select a valid JSON export file.');
          return;
        }

        let imported = 0;
        let skipped = 0;

        for (const [profileKey, noteText] of Object.entries(importedData)) {
          // Validate profile key format (supports special characters like %E2%9A%A1)
          if (!profileKey.startsWith('/in/') || typeof noteText !== 'string') {
            skipped++;
            continue;
          }

          const key = `note:${profileKey}`;
          await storageSet(key, noteText);
          // metadata is auto-saved by storageSet when note is set
          imported++;
        }

        alert(`Import complete!\n- Imported: ${imported} notes\n- Skipped: ${skipped} invalid entries`);
        importFile.value = ''; // Reset file input
        loadAndDisplayNotes();
      } catch (err) {
        console.error('[Memory Jogger] Import error:', err);
        alert('Error parsing file. Make sure it\'s a valid Memory Jogger export.');
      }
    };

    reader.readAsText(file);
  });

  // --- Diagnostics Button ---
  const diagnosticsBtn = document.getElementById('mjli-diagnostics-btn');
  if (diagnosticsBtn) {
    diagnosticsBtn.addEventListener('click', () => {
      const extensionId = chrome.runtime.id;
      const diagnosticsUrl = `chrome-extension://${extensionId}/diagnostics.html`;
      window.open(diagnosticsUrl, 'diagnostics', 'width=1000,height=800');
    });
  }

  // --- Initial Load ---
  loadAndDisplayNotes();
})();
